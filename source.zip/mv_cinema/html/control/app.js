const titleEl = document.getElementById('title');
const statusEl = document.getElementById('status');
const clockEl = document.getElementById('clock');
const mediaEl = document.getElementById('media');
const changedByEl = document.getElementById('changedBy');
const urlInput = document.getElementById('urlInput');
const playButton = document.getElementById('play');
const pauseButton = document.getElementById('pause');
const resumeButton = document.getElementById('resume');
const backButton = document.getElementById('back');
const forwardButton = document.getElementById('forward');
const stopButton = document.getElementById('stop');
const closeButton = document.getElementById('close');
const progressInput = document.getElementById('progress');
const progressNowEl = document.getElementById('progressNow');
const progressDurationEl = document.getElementById('progressDuration');
const progressHintEl = document.getElementById('progressHint');
const volumeInput = document.getElementById('volume');
const volumeValueEl = document.getElementById('volumeValue');
const toasts = document.getElementById('toasts');

const query = new URLSearchParams(window.location.search);
const resourceName = query.get('resourceName')
    || (typeof GetParentResourceName === 'function' ? GetParentResourceName() : null)
    || 'mv_cinema';

let screenId = null;
let state = { status: 'stopped', position: 0, duration: null, sourceUrl: null };
let receivedAt = performance.now();
let selectedUrl = '';
let panelOpen = false;
let scrubbing = false;
let volumeTimer = null;

async function post(endpoint, payload = {}) {
    try {
        const response = await fetch(`https://${resourceName}/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify(payload)
        });
        return await response.json();
    } catch {
        return { ok: false, error: 'Нет ответа от клиента.' };
    }
}

function formatTime(seconds) {
    const value = Math.max(0, Math.floor(Number(seconds) || 0));
    const hours = Math.floor(value / 3600);
    const minutes = Math.floor((value % 3600) / 60);
    const secs = value % 60;

    if (hours > 0) {
        return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }

    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function currentPosition() {
    const base = Number(state.position) || 0;
    if (state.status !== 'playing') return base;
    const duration = Number(state.duration) || 0;
    const value = base + ((performance.now() - receivedAt) / 1000);
    return duration > 0 ? Math.min(value, duration) : value;
}

function providerName(provider) {
    const labels = {
        youtube: 'YouTube',
        vimeo: 'Vimeo',
        twitch: 'Twitch',
        dailymotion: 'Dailymotion',
        direct: 'Прямой поток',
        generic: 'Автоопределение'
    };
    return labels[provider] || 'Видео';
}

function toast(message) {
    if (!message) return;
    const node = document.createElement('div');
    node.className = 'toast';
    node.textContent = message;
    toasts.appendChild(node);
    setTimeout(() => node.remove(), 3800);
}

function setVolume(value) {
    const next = Math.max(0, Math.min(100, Number(value) || 0));
    volumeInput.value = String(next);
    volumeValueEl.textContent = `${Math.round(next)}%`;
}

function renderState(nextState) {
    state = nextState || { status: 'stopped', position: 0, duration: null, sourceUrl: null };
    receivedAt = performance.now();

    if (state.sourceUrl && !urlInput.matches(':focus')) {
        selectedUrl = state.sourceUrl;
        urlInput.value = selectedUrl;
    }

    const stopped = state.status === 'stopped' || !state.sourceUrl;
    const playing = state.status === 'playing';
    const paused = state.status === 'paused';
    const duration = Number(state.duration) || 0;

    statusEl.textContent = playing
        ? 'ВОСПРОИЗВЕДЕНИЕ'
        : paused
            ? 'ПАУЗА'
            : 'ЭКРАН ВЫКЛЮЧЕН';

    mediaEl.textContent = stopped
        ? 'Видео не выбрано'
        : (state.displayName || `${providerName(state.provider)} · активный источник`);

    changedByEl.textContent = state.changedBy ? `Последнее действие: ${state.changedBy}` : '—';

    pauseButton.disabled = !playing;
    resumeButton.disabled = !paused;
    backButton.disabled = stopped;
    forwardButton.disabled = stopped;
    stopButton.disabled = stopped;

    progressInput.disabled = stopped || duration <= 0;
    progressInput.max = duration > 0 ? String(duration) : '1';
    progressDurationEl.textContent = duration > 0 ? formatTime(duration) : '--:--';
    progressHintEl.textContent = duration > 0
        ? 'Перетащите ползунок — новая позиция применится у всех игроков.'
        : 'Для прямого эфира или неизвестной длительности ползунок недоступен.';

    updateClock();
}

function updateClock() {
    const position = scrubbing ? Number(progressInput.value) || 0 : currentPosition();
    clockEl.textContent = formatTime(position);
    progressNowEl.textContent = formatTime(position);

    if (!scrubbing && !progressInput.disabled) {
        progressInput.value = String(position);
    }
}

async function command(name, payload = {}) {
    if (!screenId) return;
    const result = await post('controlAction', {
        screenId,
        command: name,
        payload
    });
    if (!result?.ok && result?.error) toast(result.error);
}

urlInput.addEventListener('input', () => {
    selectedUrl = urlInput.value.trim();
});

urlInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        event.preventDefault();
        playButton.click();
    }
});

playButton.addEventListener('click', () => {
    selectedUrl = urlInput.value.trim();
    if (!selectedUrl) {
        toast('Вставьте ссылку на видео.');
        urlInput.focus();
        return;
    }
    command('play', { url: selectedUrl, startAt: 0 });
});

pauseButton.addEventListener('click', () => command('pause'));
resumeButton.addEventListener('click', () => command('resume'));
backButton.addEventListener('click', () => command('seek', { delta: -10 }));
forwardButton.addEventListener('click', () => command('seek', { delta: 10 }));
stopButton.addEventListener('click', () => command('stop'));
closeButton.addEventListener('click', () => post('controlClose'));

progressInput.addEventListener('input', () => {
    scrubbing = true;
    updateClock();
});

progressInput.addEventListener('change', () => {
    const position = Number(progressInput.value) || 0;
    scrubbing = false;
    command('seek', { position });
});

volumeInput.addEventListener('input', () => {
    setVolume(volumeInput.value);
    clearTimeout(volumeTimer);
    volumeTimer = setTimeout(() => {
        post('controlVolume', { value: Number(volumeInput.value) || 0 });
    }, 100);
});

window.addEventListener('message', (event) => {
    const data = event.data || {};

    if (data.action === 'openControl') {
        panelOpen = true;
        document.body.classList.add('is-open');
        document.body.setAttribute('aria-hidden', 'false');
        screenId = data.screenId;
        titleEl.textContent = data.label || 'Управление экраном';
        setVolume(data.volume ?? 100);
        renderState(data.state);
        selectedUrl = String(data.state?.sourceUrl || '');
        urlInput.value = selectedUrl;
        requestAnimationFrame(() => urlInput.focus());
    }

    if (data.action === 'closeControl') {
        panelOpen = false;
        document.body.classList.remove('is-open');
        document.body.setAttribute('aria-hidden', 'true');
        screenId = null;
        urlInput.blur();
    }

    if (data.action === 'updateControlState' && data.screenId === screenId) {
        renderState(data.state);
        if (data.volume !== undefined) setVolume(data.volume);
    }

    if (data.action === 'setUrl') {
        selectedUrl = String(data.value || '').trim();
        }
});



window.addEventListener('contextmenu', (event) => {
    if (!panelOpen) return;
    event.preventDefault();
    post('controlClose');
});

window.addEventListener('keydown', (event) => {
    if (!panelOpen) return;
    if (event.key === 'Escape') {
        event.preventDefault();
        post('controlClose');
    }
});

setInterval(updateClock, 200);
post('controlReady');
