Config = {}

Config.Debug = false
Config.Language = 'ru'

-- Authoritative server correction. A short interval keeps late joiners and clients
-- that briefly buffered close to the same timeline without restarting the player.
Config.SyncIntervalMs = 2000
Config.DriftCorrectionSeconds = 0.75

Config.Persistence = {
    enabled = true,
    fileName = 'cinema_state.json'
}

Config.Media = {
    maxUrlLength = 2048,

    -- The player first uses known adapters and then lets MediaElement try the URL.
    -- Generic web pages are best-effort only; direct streams and official player URLs
    -- are substantially more reliable.
    allowGenericHttps = true,
    allowHttp = false,

    supported = {
        youtube = true,
        vimeo = true,
        twitch = true,
        dailymotion = true,
        direct = true,
        generic = true
    },

    -- Prevent cinema users from pointing Chromium at services on the game host or
    -- somebody's private LAN.
    blockPrivateHosts = true,
    maxDurationSeconds = 43200 -- 12 hours
}

Config.Playback = {
    entryResyncAttempts = 8,
    entryResyncIntervalMs = 350
}

Config.Controls = {
    mode = 'everyone', -- everyone / ace / jobs / ace_or_jobs
    ace = 'mv_cinema.control',
    allowedJobs = {
        cinema = 0,
        admin = 0
    },
    requireProximity = true,
    maxDistance = 4.0,
    rateLimitMs = 300
}

Config.ControlUi = {
    width = 900,
    height = 1100,
    connectionTimeoutMs = 6000,

    -- Screen-space placement of the custom DUI panel.
    centerX = 0.80,
    centerY = 0.50,
    normalizedWidth = 0.34,
    cursorSpeed = 38.0,

    -- Compact separate NUI window used only for URL entry/paste.
    urlInputTitle = 'Ссылка на видео',
    urlInputHint = 'Вставьте ссылку через Ctrl+V или введите её вручную.'
}

Config.Audio = {
    globalVolume = 1.0,
    updateIntervalMs = 100,
    interiorDiscoveryRadius = 8.0
}

Config.Runtime = {
    activateDistance = 160.0,
    deactivateDistance = 190.0,
    pollIntervalMs = 750
}

Config.Dui = {
    useRemotePlayer = true,
    width = 1920,
    height = 1080,

    -- This HTTPS player is the same foundation as the working 1.1.7 build. It can
    -- hand supported URLs to MediaElement (YouTube, Vimeo/Twitch where supported,
    -- HLS/direct files and other compatible providers).
    remotePage = 'https://kibook.github.io/pmms-dui',
    connectionTimeoutMs = 30000
}

Config.Screens = {
    {
        id = 'main_cinema',
        label = 'Кинотеатр Vinewood',

        renderMode = 'namedRenderTarget',
        model = 'v_ilev_cin_screen',
        renderTarget = 'cinscreen',

        screenPosition = vec3(338.718, 192.592, 107.029),
        renderDistance = 120.0,
        modelSearchRadius = 30.0,
        requireScreenEntity = false,

        audioPosition = vec3(338.718, 192.592, 107.029),
        audioInteriorProbe = vec3(339.010, 189.550, 103.000),

        control = {
            coords = vec3(339.010, 189.550, 103.000),
            zoneCoords = vec3(339.010, 189.550, 103.800),
            radius = 1.50,
            rotation = 351.50,
            distance = 3.0,
            drawSprite = true
        }
    }
}
