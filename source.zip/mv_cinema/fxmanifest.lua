fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'mv_cinema'
author 'OpenAI / Marvin'
description 'Single-resource synchronized cinema with ordinary URL input, custom NUI, MLO-only audio, and server persistence'
version '1.5.7'

shared_script 'config.lua'

client_scripts {
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

-- The control interface is a regular NUI page. It is fully transparent and
-- hidden until the player opens the cinema console through ox_target.
ui_page 'html/control/index.html'

files {
    'html/control/index.html',
    'html/control/style.css',
    'html/control/app.js'
}

dependencies {
    'ox_target',
    'es_extended'
}
