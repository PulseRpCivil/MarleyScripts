local RESOURCE = GetCurrentResourceName()
local states = {}
local screensById = {}
local rateLimits = {}
local ESX
local clockBaseMs = (os.time() * 1000) - GetGameTimer()

local function nowMs()
    return clockBaseMs + GetGameTimer()
end

local function trim(value)
    if type(value) ~= 'string' then return '' end
    return value:match('^%s*(.-)%s*$') or ''
end

local function notify(source, description, kind)
    TriggerClientEvent('mv_cinema:client:notify', source, tostring(description or ''), tostring(kind or 'inform'))
end

local function getScreen(screenId)
    return screensById[tostring(screenId or '')]
end

local function currentPosition(state, atMs)
    if not state or state.status == 'stopped' then return 0.0 end

    local position = tonumber(state.position) or 0.0
    if state.status == 'playing' then
        position = position + math.max(0.0, (atMs - (tonumber(state.updatedAt) or atMs)) / 1000.0)
    end

    local duration = tonumber(state.duration)
    if duration and duration > 0 then
        position = math.min(position, duration)
    end

    return math.max(0.0, position)
end

local function copyState(state)
    return {
        provider = state.provider,
        sourceUrl = state.sourceUrl,
        mediaKey = state.mediaKey,
        displayName = state.displayName,
        status = state.status,
        position = state.position,
        duration = state.duration,
        updatedAt = state.updatedAt,
        revision = state.revision,
        changedBy = state.changedBy
    }
end

local function serialiseState(screenId)
    local state = states[screenId]
    if not state then return nil end

    local sentAt = nowMs()
    return {
        screenId = screenId,
        provider = state.provider,
        sourceUrl = state.sourceUrl,
        mediaKey = state.mediaKey,
        displayName = state.displayName,
        status = state.status,
        position = currentPosition(state, sentAt),
        duration = state.duration,
        sentAt = sentAt,
        revision = state.revision,
        changedBy = state.changedBy
    }
end

local function saveStates()
    if not Config.Persistence.enabled then return end

    local payload = {}
    for screenId, state in pairs(states) do
        payload[screenId] = copyState(state)
    end

    SaveResourceFile(RESOURCE, Config.Persistence.fileName, json.encode(payload), -1)
end

local function loadStates()
    if not Config.Persistence.enabled then return end

    local raw = LoadResourceFile(RESOURCE, Config.Persistence.fileName)
    if not raw or raw == '' then return end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= 'table' then
        print(('[%s] Could not parse %s; starting with an empty cinema state.'):format(RESOURCE, Config.Persistence.fileName))
        return
    end

    for screenId, persisted in pairs(decoded) do
        if screensById[screenId] and type(persisted) == 'table' then
            states[screenId] = {
                provider = persisted.provider,
                sourceUrl = persisted.sourceUrl,
                mediaKey = persisted.mediaKey,
                displayName = persisted.displayName,
                status = persisted.status == 'playing' and 'playing' or (persisted.status == 'paused' and 'paused' or 'stopped'),
                position = tonumber(persisted.position) or 0.0,
                duration = tonumber(persisted.duration),
                updatedAt = tonumber(persisted.updatedAt) or nowMs(),
                revision = tonumber(persisted.revision) or 0,
                changedBy = persisted.changedBy
            }
        end
    end
end

local function extractYouTubeId(value)
    if type(value) ~= 'string' then return nil end

    local patterns = {
        '[?&]v=([%w_-]+)',
        'youtu%.be/([%w_-]+)',
        'youtube%.com/embed/([%w_-]+)',
        'youtube%.com/shorts/([%w_-]+)',
        'youtube%.com/live/([%w_-]+)'
    }

    for i = 1, #patterns do
        local id = value:match(patterns[i])
        if id and #id == 11 then return id end
    end

    if value:match('^[%w_-]+$') and #value == 11 then return value end
    return nil
end

local function splitUrl(url)
    local scheme, authority, rest = url:match('^(https?)://([^/%?#]+)(.*)$')
    if not scheme then return nil end

    local hostPort = authority:match('^[^@]+@(.+)$') or authority
    local host = hostPort:match('^%[([^%]]+)%]') or hostPort:match('^([^:]+)') or hostPort
    return scheme:lower(), host:lower(), rest or ''
end

local function isPrivateHost(host)
    if not host or host == '' then return true end
    if host == 'localhost' or host:sub(-6) == '.local' then return true end
    if host == '0.0.0.0' or host == '127.0.0.1' or host == '::1' then return true end
    if host:match('^127%.') or host:match('^10%.') or host:match('^192%.168%.') or host:match('^169%.254%.') then return true end

    local a, b = host:match('^(172)%.(%d+)%.')
    if a and b then
        b = tonumber(b)
        if b and b >= 16 and b <= 31 then return true end
    end

    return false
end

local function providerLabel(provider)
    local labels = {
        youtube = 'YouTube',
        vimeo = 'Vimeo',
        twitch = 'Twitch',
        dailymotion = 'Dailymotion',
        direct = 'Прямой поток',
        generic = 'Автоопределение'
    }
    return labels[provider] or provider or 'Видео'
end

local function parseMediaUrl(rawUrl)
    local value = trim(rawUrl)
    if value == '' or #value > (tonumber(Config.Media.maxUrlLength) or 2048) then
        return nil, 'Ссылка пустая или слишком длинная.'
    end

    local youtubeId = extractYouTubeId(value)
    if youtubeId and Config.Media.supported.youtube then
        local canonical = ('https://www.youtube.com/watch?v=%s'):format(youtubeId)
        return {
            provider = 'youtube',
            sourceUrl = canonical,
            mediaKey = ('youtube:%s'):format(youtubeId),
            displayName = ('YouTube · %s'):format(youtubeId)
        }
    end

    local scheme, host, rest = splitUrl(value)
    if not scheme then
        return nil, 'Введите полную ссылку, начинающуюся с https://.'
    end

    if scheme ~= 'https' and not Config.Media.allowHttp then
        return nil, 'Разрешены только HTTPS-ссылки.'
    end

    if Config.Media.blockPrivateHosts and isPrivateHost(host) then
        return nil, 'Локальные и приватные сетевые адреса запрещены.'
    end

    local provider = 'generic'
    local lower = (host .. rest):lower()

    if (host:find('vimeo.com', 1, true) or host:find('player.vimeo.com', 1, true)) and Config.Media.supported.vimeo then
        provider = 'vimeo'
    elseif (host:find('twitch.tv', 1, true) or host:find('player.twitch.tv', 1, true) or host:find('clips.twitch.tv', 1, true)) and Config.Media.supported.twitch then
        provider = 'twitch'
    elseif (host:find('dailymotion.com', 1, true) or host == 'dai.ly') and Config.Media.supported.dailymotion then
        provider = 'dailymotion'
    elseif lower:match('%.m3u8[%?#]?$') or lower:match('%.mp4[%?#]?$') or lower:match('%.webm[%?#]?$')
        or lower:match('%.ogg[%?#]?$') or lower:match('%.ogv[%?#]?$') or lower:match('%.mov[%?#]?$') then
        if not Config.Media.supported.direct then
            return nil, 'Прямые видеопотоки отключены в конфигурации.'
        end
        provider = 'direct'
    elseif not (Config.Media.allowGenericHttps and Config.Media.supported.generic) then
        return nil, 'Этот видеоресурс не поддерживается.'
    end

    return {
        provider = provider,
        sourceUrl = value,
        mediaKey = provider .. ':' .. value,
        displayName = providerLabel(provider) .. ' · ' .. host
    }
end

local function getEsx()
    if ESX then return ESX end
    if GetResourceState('es_extended') ~= 'started' then return nil end

    local ok, object = pcall(function()
        return exports['es_extended']:getSharedObject()
    end)

    if ok then ESX = object end
    return ESX
end

local function hasRolePermission(source)
    local mode = Config.Controls.mode
    if mode == 'everyone' then return true end

    if mode == 'ace' or mode == 'ace_or_jobs' then
        if IsPlayerAceAllowed(source, Config.Controls.ace) then return true end
        if mode == 'ace' then return false end
    end

    if mode == 'jobs' or mode == 'ace_or_jobs' then
        local esx = getEsx()
        if not esx then return false end

        local xPlayer = esx.GetPlayerFromId(source)
        if not xPlayer then return false end

        local job = xPlayer.getJob()
        local minimumGrade = job and Config.Controls.allowedJobs[job.name]
        return minimumGrade ~= nil and (tonumber(job.grade) or 0) >= minimumGrade
    end

    return false
end

local function isNearControl(source, screen)
    if not Config.Controls.requireProximity then return true end

    local ped = GetPlayerPed(source)
    if not ped or ped <= 0 then return false end

    local playerCoords = GetEntityCoords(ped)
    return #(playerCoords - screen.control.coords) <= Config.Controls.maxDistance
end

local function canControl(source, screenId)
    local screen = getScreen(screenId)
    if not screen then return false, 'Экран не найден.' end
    if not hasRolePermission(source) then return false, 'У вас нет доступа к управлению экраном.' end
    if not isNearControl(source, screen) then return false, 'Подойдите к пульту управления кинотеатром.' end
    return true
end

local function checkRateLimit(source)
    local at = nowMs()
    local last = rateLimits[source] or 0
    if at - last < Config.Controls.rateLimitMs then return false end
    rateLimits[source] = at
    return true
end

local function broadcastState(screenId, target)
    TriggerClientEvent('mv_cinema:client:sync', target or -1, screenId, serialiseState(screenId))
end

local function updateState(screenId, patch, source, preserveChangedBy)
    local state = states[screenId]
    if not state then return end

    for key, value in pairs(patch) do state[key] = value end
    state.revision = (tonumber(state.revision) or 0) + 1

    if not preserveChangedBy then
        state.changedBy = source and GetPlayerName(source) or state.changedBy
    end

    saveStates()
    broadcastState(screenId)
end

for i = 1, #Config.Screens do
    local screen = Config.Screens[i]
    screensById[screen.id] = screen
    states[screen.id] = {
        provider = nil,
        sourceUrl = nil,
        mediaKey = nil,
        displayName = nil,
        status = 'stopped',
        position = 0.0,
        duration = nil,
        updatedAt = nowMs(),
        revision = 0,
        changedBy = nil
    }
end

loadStates()

RegisterNetEvent('mv_cinema:server:requestControlAccess', function(requestId, screenId)
    local source = source
    local allowed, reason = canControl(source, screenId)

    TriggerClientEvent('mv_cinema:client:controlAccessResult', source, requestId, {
        allowed = allowed,
        reason = reason,
        state = serialiseState(screenId)
    })
end)

RegisterNetEvent('mv_cinema:server:requestState', function(screenId)
    local source = source
    if not getScreen(screenId) then return end
    broadcastState(screenId, source)
end)

RegisterNetEvent('mv_cinema:server:reportDuration', function(screenId, mediaKey, duration)
    screenId = tostring(screenId or '')
    local state = states[screenId]
    if not state or state.status == 'stopped' then return end
    if tostring(mediaKey or '') ~= tostring(state.mediaKey or '') then return end

    duration = tonumber(duration)
    local maximum = tonumber(Config.Media.maxDurationSeconds) or 43200
    if not duration or duration <= 0 or duration > maximum then return end

    if not state.duration or math.abs(state.duration - duration) > 0.5 then
        updateState(screenId, { duration = duration }, nil, true)
    end
end)

RegisterNetEvent('mv_cinema:server:control', function(screenId, action, payload)
    local source = source
    if not checkRateLimit(source) then return end

    local allowed, reason = canControl(source, screenId)
    if not allowed then
        notify(source, reason, 'error')
        return
    end

    local state = states[screenId]
    local at = nowMs()
    payload = type(payload) == 'table' and payload or {}

    if action == 'play' then
        local media, parseError = parseMediaUrl(payload.url)
        if not media then
            notify(source, parseError, 'error')
            return
        end

        local startAt = math.max(0.0, math.min(tonumber(Config.Media.maxDurationSeconds) or 43200, tonumber(payload.startAt) or 0.0))
        updateState(screenId, {
            provider = media.provider,
            sourceUrl = media.sourceUrl,
            mediaKey = media.mediaKey,
            displayName = media.displayName,
            status = 'playing',
            position = startAt,
            duration = nil,
            updatedAt = at
        }, source)
        notify(source, 'Видео отправлено на экран для всего зала.', 'success')
        return
    end

    if action == 'pause' then
        if state.status ~= 'playing' then return end
        updateState(screenId, {
            status = 'paused',
            position = currentPosition(state, at),
            updatedAt = at
        }, source)
        return
    end

    if action == 'resume' then
        if state.status ~= 'paused' or not state.sourceUrl then return end
        updateState(screenId, {
            status = 'playing',
            updatedAt = at
        }, source)
        return
    end

    if action == 'seek' then
        if not state.sourceUrl or state.status == 'stopped' then return end

        local target = tonumber(payload.position)
        local delta = tonumber(payload.delta)
        local position = target or (currentPosition(state, at) + (delta or 0.0))
        local maximum = tonumber(state.duration) or tonumber(Config.Media.maxDurationSeconds) or 43200
        position = math.max(0.0, math.min(maximum, position))

        updateState(screenId, {
            position = position,
            updatedAt = at
        }, source)
        return
    end

    if action == 'stop' then
        updateState(screenId, {
            provider = nil,
            sourceUrl = nil,
            mediaKey = nil,
            displayName = nil,
            status = 'stopped',
            position = 0.0,
            duration = nil,
            updatedAt = at
        }, source)
        return
    end
end)

AddEventHandler('playerDropped', function()
    rateLimits[source] = nil
end)

CreateThread(function()
    while true do
        Wait(Config.SyncIntervalMs)
        for screenId in pairs(states) do broadcastState(screenId) end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == RESOURCE then saveStates() end
end)

