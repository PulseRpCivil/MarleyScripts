local RESOURCE = GetCurrentResourceName()
local screens = {}
local targetZones = {}
local cinemaActive = false
local localVolume = 1.0
local ESX
local initializeCinema
local screenConfigs = {}
local pendingStates = {}
local testCardEnabled = false
local controlUiOpen = false
local controlScreenId = nil
local resolvedInteriorIds = {}
local controlAccessRequests = {}
local controlAccessSequence = 0
local controlDuiReady = false
local controlOpenPayload = nil

-- Keep the regular NUI page completely hidden and unfocused until ox_target
-- explicitly opens it. This prevents it from covering the character selector.
CreateThread(function()
    Wait(0)
    SendNUIMessage({ action = 'closeControl' })
    SetNuiFocus(false, false)
    pcall(function() SetNuiFocusKeepInput(false) end)
end)

for i = 1, #Config.Screens do
    local config = Config.Screens[i]
    screenConfigs[config.id] = config
end

local function notify(description, kind)
    local text = tostring(description or '')
    if text == '' then return end

    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandThefeedPostTicker(false, kind == 'error')
end

local function clamp(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, value))
end

local function asModelHash(model)
    if type(model) == 'number' then return model end
    return joaat(tostring(model or ''))
end

local function getEsx()
    if ESX then return ESX end
    if GetResourceState('es_extended') ~= 'started' then return nil end

    local ok, object = pcall(function()
        return exports['es_extended']:getSharedObject()
    end)

    if ok then ESX = object end
    return ESX
end

local function isEsxPlayerLoaded()
    local esx = getEsx()
    if not esx or type(esx.IsPlayerLoaded) ~= 'function' then return false end

    local ok, loaded = pcall(esx.IsPlayerLoaded)
    return ok and loaded == true
end

local function loadVolumePreference()
    local stored = GetResourceKvpString('mv_cinema_volume')
    local value = tonumber(stored)
    if value then
        localVolume = clamp(value, 0.0, 1.0)
    end
end

local function saveVolumePreference()
    SetResourceKvp('mv_cinema_volume', tostring(localVolume))
end

local sendDui

local function createNamedRenderTarget(modelHash, targetName)
    if not targetName or targetName == '' or not modelHash or modelHash == 0 then
        return 0
    end

    if not IsNamedRendertargetRegistered(targetName) then
        RegisterNamedRendertarget(targetName, false)
    end

    if not IsNamedRendertargetLinked(modelHash) then
        LinkNamedRendertarget(modelHash)
    end

    if IsNamedRendertargetRegistered(targetName) and IsNamedRendertargetLinked(modelHash) then
        return GetNamedRendertargetRenderId(targetName)
    end

    return 0
end

local function createRuntimeTexture(runtime, config)
    runtime.runtimeTxdName = ('mv_cinema_%s_txd'):format(config.id)
    runtime.runtimeTxnName = ('mv_cinema_%s_txn'):format(config.id)
    runtime.runtimeTxd = CreateRuntimeTxd(runtime.runtimeTxdName)
    runtime.duiHandle = GetDuiHandle(runtime.dui)
    runtime.runtimeTexture = CreateRuntimeTextureFromDuiHandle(
        runtime.runtimeTxd,
        runtime.runtimeTxnName,
        runtime.duiHandle
    )

    return runtime.runtimeTexture ~= nil
end

local function findScreenByMediaHandle(handle)
    local wanted = tostring(handle or '')
    for _, screenData in pairs(screens) do
        if tostring(screenData.mediaHandle or '') == wanted then
            return screenData
        end
    end
    return nil
end

local function getPlaybackPosition(screenData)
    local state = screenData.state or {}
    local position = tonumber(state.position) or 0.0

    if state.status == 'playing' and screenData.stateReceivedAt then
        position = position + math.max(0.0, (GetGameTimer() - screenData.stateReceivedAt) / 1000.0)
    end

    return math.max(0.0, position)
end

local function mediaUrlFromState(state)
    if not state or not state.sourceUrl then return nil end
    return tostring(state.sourceUrl)
end

local function sendRawDui(screenData, payload)
    if not screenData or not screenData.dui or not IsDuiAvailable(screenData.dui) then return false end
    SendDuiMessage(screenData.dui, json.encode(payload))
    return true
end

local function remoteVolumePercent(screenData)
    return remoteVolumePercent(screenData)
end

local function remoteOptions(screenData, url)
    local state = screenData.state or {}
    local volume = remoteVolumePercent(screenData)
    return {
        url = url,
        title = screenData.config.label or 'Кинотеатр',
        offset = getPlaybackPosition(screenData),
        duration = tonumber(state.duration) or screenData.mediaDuration or false,
        paused = state.status ~= 'playing',
        loop = false,
        filter = false,
        visualization = false,
        muted = volume <= 0,
            volume = volume,
        range = 1000.0,
        attenuation = { sameRoom = 0.0, diffRoom = 0.0 },
        diffRoomVolume = 1.0,
        video = true,
        videoSize = 0
    }
end

local function syncRemoteDui(screenData, forceInit)
    if not screenData or not screenData.duiConnected then
        if screenData then screenData.pendingSync = true end
        return
    end

    local state = screenData.state or { status = 'stopped' }
    local url = mediaUrlFromState(state)

    if not url or state.status == 'stopped' then
        if screenData.currentMediaKey then
            sendRawDui(screenData, {
                type = 'stop',
                handle = screenData.mediaHandle
            })
        end
        screenData.currentMediaKey = nil
        screenData.playerInitialized = false
        screenData.initRequested = false
        screenData.mediaDuration = nil
        screenData.pendingSync = false
        return
    end

    local key = tostring(state.mediaKey or (tostring(state.provider) .. ':' .. tostring(state.sourceUrl)))
    local options = remoteOptions(screenData, url)

    if forceInit or screenData.currentMediaKey ~= key or (not screenData.playerInitialized and not screenData.initRequested) then
        if screenData.currentMediaKey and screenData.currentMediaKey ~= key then
            sendRawDui(screenData, {
                type = 'stop',
                handle = screenData.mediaHandle
            })
        end

        screenData.currentMediaKey = key
        screenData.playerInitialized = false
        screenData.initRequested = true
        screenData.mediaDuration = nil

        sendRawDui(screenData, {
            type = 'init',
            handle = screenData.mediaHandle,
            url = url,
            options = options
        })
    else
        sendRawDui(screenData, {
            type = 'update',
            handle = screenData.mediaHandle,
            options = options,
            distance = 0.0,
            sameRoom = true,
            volume = remoteVolumePercent(screenData)
        })
    end

    screenData.pendingSync = false
end

sendDui = function(screenData, payload)
    if not screenData then return end

    if Config.Dui.useRemotePlayer then
        if payload.action == 'sync' then
            screenData.state = payload.state or screenData.state
            screenData.stateReceivedAt = GetGameTimer()
            syncRemoteDui(screenData, false)
        elseif payload.action == 'volume' then
            screenData.currentVolume = clamp(tonumber(payload.volume) or 0.0, 0.0, 1.0)
            syncRemoteDui(screenData, false)
        end
        return
    end

    sendRawDui(screenData, payload)
end

RegisterNUICallback('duiStartup', function(_, cb)
    cb({
        isRDR = false,
        audioVisualizations = {},
        currentServerEndpoint = GetCurrentServerEndpoint()
    })
end)

RegisterNUICallback('DuiBrowser:initDone', function(data, cb)
    local screenData = findScreenByMediaHandle(data and data.handle)
    if screenData then
        screenData.duiConnected = true
        syncRemoteDui(screenData, true)
        print(('[%s] HTTPS DUI player connected for screen %s.'):format(RESOURCE, screenData.config.id))
    end
    cb({})
end)

RegisterNUICallback('init', function(data, cb)
    local screenData = findScreenByMediaHandle(data and data.handle)
    if screenData then
        screenData.playerInitialized = true
        screenData.lastVolume = -1.0
        screenData.initRequested = false
        screenData.mediaDuration = data.options and tonumber(data.options.duration) or nil

        if screenData.mediaDuration and screenData.mediaDuration > 0 and screenData.state and screenData.state.mediaKey then
            TriggerServerEvent(
                'mv_cinema:server:reportDuration',
                screenData.config.id,
                screenData.state.mediaKey,
                screenData.mediaDuration
            )
        end

        syncRemoteDui(screenData, false)

    -- The remote PMMS/YouTube player can finish initializing after the
    -- first volume packet. Re-send the authoritative MLO volume for a
    -- few seconds so CEF cannot leave the player muted at startup.
    CreateThread(function()
        for attempt = 1, 10 do
            if not screenData.dui or not screenData.playerInitialized then
                return
            end

            local state = screenData.state or {}
            local url = mediaUrlFromState(state)
            if url and state.status ~= 'stopped' then
                local volume = remoteVolumePercent(screenData)
                sendRawDui(screenData, {
                    type = 'update',
                    handle = screenData.mediaHandle,
                    options = remoteOptions(screenData, url),
                    distance = 0.0,
                    sameRoom = true,
                    muted = volume <= 0,
                    volume = volume
                })
            end

            Wait(400)
        end
    end)
        print(('[%s] Media player initialized for screen %s (duration=%s).'):format(
            RESOURCE,
            screenData.config.id,
            tostring(screenData.mediaDuration)
        ))
    end
    cb({})
end)

local function reportDuiError(kind, data)
    local url = data and data.url or 'unknown'
    local message = data and data.message or 'unknown error'
    print(('[%s] DUI %s error for %s: %s'):format(RESOURCE, kind, tostring(url), tostring(message)))
    notify(('Ошибка воспроизведения: %s'):format(tostring(message)), 'error')
end

RegisterNUICallback('initError', function(data, cb)
    reportDuiError('init', data)
    cb({})
end)

RegisterNUICallback('playError', function(data, cb)
    reportDuiError('play', data)
    cb({})
end)

local function createScreenDui(config)
    local runtime = {
        config = config,
        state = {
            status = 'stopped',
            position = 0.0
        },
        lastVolume = -1.0
    }

    runtime.mediaHandle = config.id
    runtime.currentVolume = 0.0
    runtime.duiConnected = not Config.Dui.useRemotePlayer
    runtime.playerInitialized = false
    runtime.initRequested = false
    runtime.pendingSync = false
    runtime.stateReceivedAt = GetGameTimer()
    runtime.wasInsideMlo = false
    runtime.entrySyncGeneration = 0

    -- Prepare the world render target before the browser connects. This makes the
    -- direct test card independent from YouTube, HTTPS and even DUI availability.
    if config.renderMode == 'namedRenderTarget' then
        runtime.modelHash = asModelHash(config.model)
        runtime.renderTargetName = tostring(config.renderTarget or '')
        runtime.renderTargetHandle = nil
        runtime.screenEntity = 0
        runtime.nextEntityCheck = 0
        runtime.renderReady = runtime.modelHash ~= 0 and runtime.renderTargetName ~= ''

        if not runtime.renderReady then
            print(('[%s] Invalid named render target configuration for screen %s.'):format(RESOURCE, config.id))
            return runtime
        end
    elseif config.renderMode == 'replaceTexture' then
        if not config.originalTxd or not config.originalTxn
            or config.originalTxd:find('CHANGE_ME', 1, true)
            or config.originalTxn:find('CHANGE_ME', 1, true) then
            print(('[%s] Screen %s is not configured: set originalTxd and originalTxn in config.lua.'):format(RESOURCE, config.id))
            return runtime
        end

        runtime.renderReady = true
    else
        print(('[%s] Unsupported renderMode "%s" for screen %s.'):format(RESOURCE, tostring(config.renderMode), config.id))
        return runtime
    end

    local duiUrl
    if Config.Dui.useRemotePlayer then
        local separator = Config.Dui.remotePage:find('?', 1, true) and '&' or '?'
        duiUrl = ('%s%sresourceName=%s&screen=%s'):format(
            Config.Dui.remotePage,
            separator,
            RESOURCE,
            config.id
        )
    else
        duiUrl = ('https://cfx-nui-%s/html/screen/index.html?screen=%s&drift=%s'):format(
            RESOURCE,
            config.id,
            Config.DriftCorrectionSeconds
        )
    end

    runtime.duiUrl = duiUrl
    runtime.dui = CreateDui(duiUrl, Config.Dui.width, Config.Dui.height)

    CreateThread(function()
        local timeoutAt = GetGameTimer() + 15000
        while cinemaActive and runtime.dui and not IsDuiAvailable(runtime.dui) and GetGameTimer() < timeoutAt do
            Wait(100)
        end

        if not cinemaActive or not runtime.dui then return end

        if not IsDuiAvailable(runtime.dui) then
            print(('[%s] DUI for screen %s did not become available. URL: %s'):format(RESOURCE, config.id, runtime.duiUrl))
            return
        end

        -- PMMS creates its runtime texture before waiting for the HTTPS page handshake.
        -- Doing the same prevents a failed remote callback from blocking all drawing.
        if not createRuntimeTexture(runtime, config) then
            print(('[%s] Could not create runtime DUI texture for screen %s.'):format(RESOURCE, config.id))
            return
        end

        if config.renderMode == 'replaceTexture' then
            AddReplaceTexture(
                config.originalTxd,
                config.originalTxn,
                runtime.runtimeTxdName,
                runtime.runtimeTxnName
            )

            runtime.textureApplied = true
        end

        if Config.Dui.useRemotePlayer then
            local connectUntil = GetGameTimer() + (tonumber(Config.Dui.connectionTimeoutMs) or 30000)
            while cinemaActive and runtime.dui and not runtime.duiConnected and GetGameTimer() < connectUntil do
                sendRawDui(runtime, {
                    type = 'DuiBrowser:init',
                    handle = runtime.mediaHandle
                })
                Wait(250)
            end

            if not runtime.duiConnected then
                print(('[%s] HTTPS DUI page did not answer for screen %s. URL: %s'):format(RESOURCE, config.id, runtime.duiUrl))
            end
        end

        TriggerServerEvent('mv_cinema:server:requestState', config.id)
    end)

    return runtime
end

local function destroyScreenDui(screenData)
    if not screenData then return end

    if screenData.textureApplied then
        RemoveReplaceTexture(screenData.config.originalTxd, screenData.config.originalTxn)
        screenData.textureApplied = false
    end

    if screenData.renderTargetName and IsNamedRendertargetRegistered(screenData.renderTargetName) then
        SetTextRenderId(GetDefaultScriptRendertargetRenderId())
        ReleaseNamedRendertarget(screenData.renderTargetName)
        screenData.renderTargetHandle = nil
    end

    if screenData.dui then
        DestroyDui(screenData.dui)
        screenData.dui = nil
    end
end

local function getStreamedScreenEntity(screenData)
    local now = GetGameTimer()
    if screenData.screenEntity and screenData.screenEntity ~= 0 and DoesEntityExist(screenData.screenEntity) then
        return screenData.screenEntity
    end

    if now < (screenData.nextEntityCheck or 0) then
        return 0
    end

    screenData.nextEntityCheck = now + 1000

    local position = screenData.config.screenPosition or screenData.config.audioPosition
    local radius = tonumber(screenData.config.modelSearchRadius) or 30.0
    local entity = GetClosestObjectOfType(
        position.x, position.y, position.z,
        radius,
        screenData.modelHash,
        false, false, false
    )

    if entity and entity ~= 0 and DoesEntityExist(entity) then
        screenData.screenEntity = entity
        return entity
    end

    screenData.screenEntity = 0
    return 0
end

local function isValidNamedTargetHandle(handle)
    if not handle or handle == 0 then return false end
    return handle ~= GetDefaultScriptRendertargetRenderId()
end

local function nearestScreen(maxDistance)
    local ped = PlayerPedId()
    if ped == 0 or not DoesEntityExist(ped) then return nil end

    local playerCoords = GetEntityCoords(ped)
    local nearestId, nearestDistance

    for screenId, config in pairs(screenConfigs) do
        local control = config.control
        if control and control.coords then
            local distance = #(playerCoords - control.coords)
            if distance <= maxDistance and (not nearestDistance or distance < nearestDistance) then
                nearestId = screenId
                nearestDistance = distance
            end
        end
    end

    return nearestId, nearestDistance
end


local function releaseControlFocus()
    SetNuiFocus(false, false)
    pcall(function() SetNuiFocusKeepInput(false) end)
end

local function closeControlUi()
    controlUiOpen = false
    controlScreenId = nil
    controlOpenPayload = nil
    SendNUIMessage({ action = 'closeControl' })
    releaseControlFocus()
end

local function sendControlMessage(payload)
    SendNUIMessage(payload)
    return true
end

local function sendControlState(screenId, state)
    if not controlUiOpen or controlScreenId ~= screenId then return end

    sendControlMessage({
        action = 'updateControlState',
        screenId = screenId,
        state = state or { status = 'stopped', position = 0.0 },
        volume = math.floor(localVolume * 100.0 + 0.5)
    })
end

local function triggerControl(screenId, action, payload)
    TriggerServerEvent('mv_cinema:server:control', screenId, action, payload or {})
end

local function setLocalVolume(value)
    localVolume = clamp(tonumber(value) or localVolume, 0.0, 1.0)
    saveVolumePreference()

    for _, screenData in pairs(screens) do
        screenData.lastVolume = -1.0
    end
end

RegisterNetEvent('mv_cinema:client:controlAccessResult', function(requestId, response)
    local pending = controlAccessRequests[tonumber(requestId)]
    if not pending then return end

    controlAccessRequests[tonumber(requestId)] = nil
    pending:resolve(response)
end)

local function requestControlAccess(screenId)
    controlAccessSequence = controlAccessSequence + 1
    if controlAccessSequence > 1000000 then controlAccessSequence = 1 end

    local requestId = controlAccessSequence
    local pending = promise.new()
    controlAccessRequests[requestId] = pending

    TriggerServerEvent('mv_cinema:server:requestControlAccess', requestId, screenId)

    SetTimeout(5000, function()
        local waiting = controlAccessRequests[requestId]
        if not waiting then return end

        controlAccessRequests[requestId] = nil
        waiting:resolve(nil)
    end)

    return Citizen.Await(pending)
end

local function openControl(screenId)
    local config = screenConfigs[screenId]
    if not config then
        notify('Конфигурация киноэкрана не найдена.', 'error')
        return
    end

    if not cinemaActive then initializeCinema() end

    local screenData = screens[screenId] or {
        config = config,
        state = { status = 'stopped', position = 0.0 }
    }

    local response = requestControlAccess(screenId)
    if not response or not response.allowed then
        notify(response and response.reason or 'Не удалось проверить доступ.', 'error')
        return
    end

    if response.state then
        screenData.state = response.state
        pendingStates[screenId] = response.state
    end

    controlUiOpen = true
    controlScreenId = screenId

    controlOpenPayload = {
        action = 'openControl',
        screenId = screenId,
        label = config.label or 'Кинотеатр',
        state = screenData.state or { status = 'stopped', position = 0.0 },
        volume = math.floor(localVolume * 100.0 + 0.5),
        maxUrlLength = tonumber(Config.Media.maxUrlLength) or 2048
    }

    SetNuiFocus(true, true)
    pcall(function() SetNuiFocusKeepInput(false) end)
    pcall(function()
        SetCursorLocation(tonumber(Config.ControlUi.centerX) or 0.80, tonumber(Config.ControlUi.centerY) or 0.50)
    end)

    sendControlMessage(controlOpenPayload)

    -- Repeat briefly in case the NUI document has just been loaded from cache.
    CreateThread(function()
        for _ = 1, 10 do
            if not controlUiOpen or not controlOpenPayload then return end
            if controlDuiReady then return end
            sendControlMessage(controlOpenPayload)
            Wait(100)
        end
    end)
end

RegisterNUICallback('controlReady', function(_, cb)
    controlDuiReady = true
    if controlUiOpen and controlOpenPayload then
        sendControlMessage(controlOpenPayload)
    else
        SendNUIMessage({ action = 'closeControl' })
        releaseControlFocus()
    end
    cb({ ok = true })
end)

RegisterNUICallback('controlClose', function(_, cb)
    closeControlUi()
    cb({ ok = true })
end)

RegisterNUICallback('controlAction', function(data, cb)
    data = type(data) == 'table' and data or {}

    local screenId = tostring(data.screenId or '')
    if not controlUiOpen or controlScreenId ~= screenId then
        cb({ ok = false, error = 'Панель управления закрыта.' })
        return
    end

    local allowedActions = {
        play = true,
        pause = true,
        resume = true,
        seek = true,
        stop = true
    }

    local action = tostring(data.command or '')
    if not allowedActions[action] then
        cb({ ok = false, error = 'Неизвестная команда.' })
        return
    end

    triggerControl(screenId, action, type(data.payload) == 'table' and data.payload or {})
    cb({ ok = true })
end)

RegisterNUICallback('controlVolume', function(data, cb)
    local value = tonumber(type(data) == 'table' and data.value or nil)
    if value == nil then
        cb({ ok = false })
        return
    end

    setLocalVolume(value / 100.0)
    cb({ ok = true })
end)

local function removeTargetZones()
    if GetResourceState('ox_target') == 'started' then
        for _, zone in pairs(targetZones) do
            local shouldRemove = true
            local ok, exists = pcall(function()
                return exports.ox_target:zoneExists(zone.id or zone.name)
            end)
            if ok then shouldRemove = exists == true end

            if shouldRemove then
                pcall(function()
                    exports.ox_target:removeZone(zone.id or zone.name)
                end)
            end
        end
    end

    targetZones = {}
end

local function targetZoneExists(zone)
    if not zone then return false end
    if GetResourceState('ox_target') ~= 'started' then return false end

    local ok, exists = pcall(function()
        return exports.ox_target:zoneExists(zone.id or zone.name)
    end)

    -- Older ox_target builds may not expose zoneExists; a successfully returned ID
    -- is still considered registered in that case.
    if not ok then
        return zone.id ~= nil
    end

    return exists == true
end

local function addTargetZones()
    removeTargetZones()

    if GetResourceState('ox_target') ~= 'started' then
        print(('[%s] ox_target is not started; cinema control zones will be retried automatically.'):format(RESOURCE))
        return false
    end

    local created = 0

    -- Register controls from Config.Screens directly. This is intentionally independent
    -- from ESX playerLoaded and from DUI creation, so the target never silently disappears.
    for i = 1, #Config.Screens do
        local config = Config.Screens[i]
        local screenId = config.id
        local control = config.control

        if control and control.coords then
            local capturedScreenId = screenId
            local zoneName = ('mv_cinema_control_%s'):format(capturedScreenId)
            local zoneCoords = control.zoneCoords or vec3(
                control.coords.x,
                control.coords.y,
                control.coords.z + 0.80
            )

            local ok, zoneId = pcall(function()
                return exports.ox_target:addSphereZone({
                    name = zoneName,
                    coords = zoneCoords,
                    radius = tonumber(control.radius) or 1.50,
                    debug = Config.Debug == true,
                    drawSprite = control.drawSprite ~= false,
                    options = {
                        {
                            name = ('mv_cinema_option_%s'):format(capturedScreenId),
                            icon = 'fa-solid fa-film',
                            label = 'Управление кинотеатром',
                            distance = tonumber(control.distance) or 3.0,
                            onSelect = function()
                                CreateThread(function()
                                    openControl(capturedScreenId)
                                end)
                            end
                        }
                    }
                })
            end)

            if ok and zoneId then
                targetZones[capturedScreenId] = {
                    id = zoneId,
                    name = zoneName,
                    coords = zoneCoords
                }
                created = created + 1
                print(('[%s] ox_target sphere created: %s id=%s coords=%s radius=%.2f'):format(
                    RESOURCE,
                    zoneName,
                    tostring(zoneId),
                    tostring(zoneCoords),
                    tonumber(control.radius) or 1.50
                ))
            else
                print(('[%s] Failed to create ox_target zone %s: %s'):format(
                    RESOURCE,
                    zoneName,
                    tostring(zoneId)
                ))
            end
        end
    end

    return created > 0
end

local function shutdownCinema()
    if not cinemaActive then return end
    cinemaActive = false

    closeControlUi()

    SetTextRenderId(GetDefaultScriptRendertargetRenderId())
    SetScriptGfxDrawBehindPausemenu(0)
    testCardEnabled = false

    for _, screenData in pairs(screens) do
        destroyScreenDui(screenData)
    end

    screens = {}
end

initializeCinema = function()
    if cinemaActive then return end
    cinemaActive = true

    for i = 1, #Config.Screens do
        local config = Config.Screens[i]
        screens[config.id] = createScreenDui(config)

        local cached = pendingStates[config.id]
        if cached then
            screens[config.id].state = cached
            screens[config.id].stateReceivedAt = GetGameTimer()
            sendDui(screens[config.id], { action = 'sync', state = cached })
        end
    end

    CreateThread(function()
        Wait(500)
        if not cinemaActive then return end

        for screenId in pairs(screens) do
            TriggerServerEvent('mv_cinema:server:requestState', screenId)
        end
    end)
end

RegisterNetEvent('mv_cinema:client:notify', function(description, kind)
    notify(description, kind)
end)

RegisterNetEvent('mv_cinema:client:sync', function(screenId, state)
    if type(state) ~= 'table' then return end
    pendingStates[screenId] = state

    if not cinemaActive then return end

    local screenData = screens[screenId]
    if not screenData then return end

    screenData.state = state
    screenData.stateReceivedAt = GetGameTimer()
    sendDui(screenData, {
        action = 'sync',
        state = state
    })

    sendControlState(screenId, state)
end)

RegisterNetEvent('esx:onPlayerLogout', function()
    closeControlUi()
    shutdownCinema()
end)

RegisterNetEvent('esx:playerLogout', function()
    closeControlUi()
    shutdownCinema()
end)

-- Register the ox_target control as soon as ox_target is available.
-- It must not depend on ESX.IsPlayerLoaded(), because multicharacter implementations
-- do not all update that flag in the same way.
CreateThread(function()
    while GetResourceState('ox_target') ~= 'started' do
        Wait(500)
    end

    Wait(500)
    addTargetZones()
end)

-- Start the browser only near the cinema. This avoids full-map background DUI work and,
-- more importantly, does not depend on ESX.IsPlayerLoaded(), which is unreliable with
-- some multicharacter implementations.
CreateThread(function()
    loadVolumePreference()

    local activateDistance = tonumber(Config.Runtime and Config.Runtime.activateDistance) or 160.0
    local deactivateDistance = tonumber(Config.Runtime and Config.Runtime.deactivateDistance) or 190.0
    local pollInterval = tonumber(Config.Runtime and Config.Runtime.pollIntervalMs) or 750

    while true do
        local ped = PlayerPedId()
        local playerReady = NetworkIsPlayerActive(PlayerId())
            and ped ~= 0
            and DoesEntityExist(ped)
            and not IsPlayerSwitchInProgress()

        local nearestDistance
        if playerReady then
            local playerCoords = GetEntityCoords(ped)
            for _, config in pairs(screenConfigs) do
                local screenPosition = config.screenPosition or config.audioPosition or (config.control and config.control.coords)
                if screenPosition then
                    local distance = #(playerCoords - screenPosition)
                    if not nearestDistance or distance < nearestDistance then
                        nearestDistance = distance
                    end
                end
            end
        end

        if playerReady and nearestDistance and nearestDistance <= activateDistance then
            if not cinemaActive then
                initializeCinema()
            end
        elseif cinemaActive and (not playerReady or not nearestDistance or nearestDistance >= deactivateDistance) then
            shutdownCinema()
        end

        Wait(pollInterval)
    end
end)

-- Draw only while the player is near the mapped screen object.
CreateThread(function()
    while true do
        if not cinemaActive then
            Wait(1000)
        else
            local ped = PlayerPedId()
            local canRender = NetworkIsPlayerActive(PlayerId())
                and ped ~= 0
                and DoesEntityExist(ped)
                and not IsPlayerSwitchInProgress()
                and not IsPauseMenuActive()

            local drewFrame = false

            if canRender then
                local playerCoords = GetEntityCoords(ped)

                for _, screenData in pairs(screens) do
                    local config = screenData.config

                    if config.renderMode == 'namedRenderTarget' and screenData.renderReady and (screenData.runtimeTexture or testCardEnabled) then
                        local screenPosition = config.screenPosition or config.audioPosition
                        local renderDistance = tonumber(config.renderDistance) or 100.0
                        local distance = #(playerCoords - screenPosition)

                        local screenEntityReady = true
                        if config.requireScreenEntity == true then
                            screenEntityReady = getStreamedScreenEntity(screenData) ~= 0
                        end

                        if distance <= renderDistance and screenEntityReady then
                            if not isValidNamedTargetHandle(screenData.renderTargetHandle)
                                or not IsNamedRendertargetRegistered(screenData.renderTargetName)
                                or not IsNamedRendertargetLinked(screenData.modelHash) then
                                screenData.renderTargetHandle = createNamedRenderTarget(
                                    screenData.modelHash,
                                    screenData.renderTargetName
                                )
                            end

                            local handle = screenData.renderTargetHandle
                            if isValidNamedTargetHandle(handle) then
                                drewFrame = true
                                local defaultHandle = GetDefaultScriptRendertargetRenderId()

                                SetTextRenderId(handle)
                                Set_2dLayer(4)
                                SetScriptGfxDrawBehindPausemenu(1)
                                DrawRect(0.5, 0.5, 1.0, 1.0, 0, 0, 0, 255)

                                if testCardEnabled then
                                    local bars = {
                                        { 235, 235, 235 },
                                        { 235, 235, 16 },
                                        { 16, 235, 235 },
                                        { 16, 235, 16 },
                                        { 235, 16, 235 },
                                        { 235, 16, 16 },
                                        { 16, 16, 235 }
                                    }

                                    for index = 1, #bars do
                                        local colour = bars[index]
                                        DrawRect((index - 0.5) / #bars, 0.43, 1.0 / #bars, 0.72, colour[1], colour[2], colour[3], 255)
                                    end

                                    DrawRect(0.5, 0.88, 1.0, 0.18, 18, 18, 18, 255)
                                    DrawRect(0.25, 0.88, 0.18, 0.08, 255, 255, 255, 255)
                                    DrawRect(0.50, 0.88, 0.18, 0.08, 128, 128, 128, 255)
                                    DrawRect(0.75, 0.88, 0.18, 0.08, 32, 32, 32, 255)
                                elseif screenData.runtimeTexture then
                                    DrawSprite(
                                        screenData.runtimeTxdName,
                                        screenData.runtimeTxnName,
                                        0.5, 0.5, 1.0, 1.0,
                                        0.0,
                                        255, 255, 255, 255
                                    )
                                end

                                SetTextRenderId(defaultHandle)
                                SetScriptGfxDrawBehindPausemenu(0)
                            else
                                screenData.renderTargetHandle = nil
                            end
                        end
                    end
                end
            end

            Wait(drewFrame and 0 or 500)
        end
    end
end)

local function resolveCinemaInterior(screenData, ped)
    local screenId = screenData.config.id
    local cached = resolvedInteriorIds[screenId]

    if cached and cached ~= 0 then
        return cached
    end

    local probe = screenData.config.audioInteriorProbe
        or screenData.config.audioPosition
        or screenData.config.screenPosition

    if probe then
        local interior = GetInteriorAtCoords(probe.x, probe.y, probe.z)
        if interior and interior ~= 0 then
            resolvedInteriorIds[screenId] = interior
            return interior
        end
    end

    -- Some streamed MLOs expose their interior ID only after the local player enters.
    -- The configured console is physically inside the uploaded MLO, so it is a safe
    -- one-time discovery point and does not leak sound to neighbouring interiors.
    if ped and ped ~= 0 and DoesEntityExist(ped) then
        local control = screenData.config.control
        local playerInterior = GetInteriorFromEntity(ped)

        if control and control.coords and playerInterior and playerInterior ~= 0 then
            local playerCoords = GetEntityCoords(ped)
            local discoveryRadius = tonumber(Config.Audio.interiorDiscoveryRadius) or 8.0

            if #(playerCoords - control.coords) <= discoveryRadius then
                resolvedInteriorIds[screenId] = playerInterior
                return playerInterior
            end
        end
    end

    return 0
end

local function isInsideCinemaMlo(screenData, ped)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end

    local playerInterior = GetInteriorFromEntity(ped)
    if not playerInterior or playerInterior == 0 then return false end

    local cinemaInterior = resolveCinemaInterior(screenData, ped)
    return cinemaInterior ~= 0 and playerInterior == cinemaInterior
end

local function resyncOnMloEntry(screenData)
    if not screenData or not screenData.config then return end

    screenData.entrySyncGeneration = (screenData.entrySyncGeneration or 0) + 1
    local generation = screenData.entrySyncGeneration
    local attempts = math.max(1, tonumber(Config.Playback.entryResyncAttempts) or 5)
    local interval = math.max(100, tonumber(Config.Playback.entryResyncIntervalMs) or 500)

    -- Ask the server for the authoritative position immediately. This is independent
    -- from the player who originally started the film, so reconnects and late entries
    -- always join the currently running timeline.
    TriggerServerEvent('mv_cinema:server:requestState', screenData.config.id)

    CreateThread(function()
        for attempt = 1, attempts do
            if not cinemaActive or not screens[screenData.config.id] then return end
            if generation ~= screenData.entrySyncGeneration then return end

            if screenData.state and screenData.state.status ~= 'stopped' then
                syncRemoteDui(screenData, false)
            end

            if attempt < attempts then
                Wait(interval)
            end
        end
    end)
end


CreateThread(function()
    while true do
        if not cinemaActive then
            Wait(1000)
        else
            local ped = PlayerPedId()

            for _, screenData in pairs(screens) do
                local insideMlo = isInsideCinemaMlo(screenData, ped)

                if insideMlo and not screenData.wasInsideMlo then
                    screenData.wasInsideMlo = true
                    screenData.lastVolume = -1.0
                    resyncOnMloEntry(screenData)
                elseif not insideMlo and screenData.wasInsideMlo then
                    screenData.wasInsideMlo = false
                    screenData.entrySyncGeneration = (screenData.entrySyncGeneration or 0) + 1
                    screenData.lastVolume = -1.0
                end

                local volume = insideMlo
                    and clamp(localVolume * Config.Audio.globalVolume, 0.0, 1.0)
                    or 0.0

                if math.abs(volume - screenData.lastVolume) >= 0.005 then
                    screenData.lastVolume = volume
                    sendDui(screenData, {
                        action = 'volume',
                        volume = volume
                    })
                end
            end

            Wait(Config.Audio.updateIntervalMs)
        end
    end
end)

-- Recreate the control zone if ox_target starts/restarts after mv_cinema,
-- or if another resource removed the zone at runtime.
CreateThread(function()
    while true do
        if GetResourceState('ox_target') == 'started' then
            local missing = next(targetZones) == nil

            if not missing then
                for _, zone in pairs(targetZones) do
                    if not targetZoneExists(zone) then
                        missing = true
                        break
                    end
                end
            end

            if missing then
                addTargetZones()
            end
        end

        Wait(2000)
    end
end)

AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName == RESOURCE then
        SendNUIMessage({ action = 'closeControl' })
        SetNuiFocus(false, false)
        pcall(function() SetNuiFocusKeepInput(false) end)
        return
    end

    if resourceName ~= 'ox_target' then return end

    CreateThread(function()
        Wait(750)
        addTargetZones()
    end)
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == 'ox_target' then
        targetZones = {}
        return
    end

    if resourceName == RESOURCE then
        closeControlUi()
        removeTargetZones()
        shutdownCinema()
    end
end)
